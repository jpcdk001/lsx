module.exports = {
  plugins: ['preset-github']
};

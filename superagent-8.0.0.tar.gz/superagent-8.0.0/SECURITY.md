# Security Policy


## Reporting a Vulnerability

Please report security issues to `niftylettuce@gmail.com`

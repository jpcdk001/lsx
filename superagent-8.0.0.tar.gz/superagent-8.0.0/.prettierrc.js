module.exports = {
  singleQuote: true,
  bracketSpacing: true,
  trailingComma: 'none'
};
